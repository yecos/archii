'use client';

export default function Page() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#0f1117', color: '#c8a96e', fontFamily: 'sans-serif' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🏗️</div>
        <h1 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>ArchiFlow</h1>
        <p style={{ opacity: 0.7 }}>Gestión de Proyectos de Arquitectura</p>
        <p style={{ marginTop: '2rem', fontSize: '0.85rem', opacity: 0.5 }}>v1.0 — Prueba de despliegue</p>
      </div>
    </div>
  );
}
