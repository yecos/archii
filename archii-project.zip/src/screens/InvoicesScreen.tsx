'use client';
import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { fmtCOP } from '@/lib/helpers';
import { DEFAULT_PHASES } from '@/lib/types';
import { getFirebase } from '@/lib/firebase-service';

export default function InvoicesScreen() {
  const {
    addInvoiceItem, forms, invoiceFilterStatus, invoiceItems, invoiceTab,
    invoices, openNewInvoice, projects, removeInvoiceItem, saveInvoice,
    setForms, setInvoiceFilterStatus, setInvoiceTab, showToast, updateInvoiceItem,
  } = useApp();

  return (
<div className="animate-fadeIn space-y-4">
        {invoiceTab === 'list' && (<div>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div className="flex gap-1 bg-[var(--af-bg3)] rounded-lg p-1 overflow-x-auto">
              {[{ k: 'Todas', v: 'all' }, { k: 'Borrador', v: 'Borrador' }, { k: 'Enviadas', v: 'Enviada' }, { k: 'Pagadas', v: 'Pagada' }, { k: 'Vencidas', v: 'Vencida' }].map(tab => (
                <button key={tab.v} className={`px-3 py-1.5 rounded-md text-[13px] cursor-pointer transition-all whitespace-nowrap ${invoiceFilterStatus === tab.v ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)] hover:text-[var(--foreground)]'}`} onClick={() => setInvoiceFilterStatus(tab.v)}>{tab.k}</button>
              ))}
            </div>
            <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3.5 py-2 rounded-lg text-[13px] font-semibold cursor-pointer border-none hover:bg-[var(--af-accent2)] transition-colors" onClick={openNewInvoice}>+ Nueva Factura</button>
          </div>
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            {(() => {
              const totalInvoiced = invoices.filter(i => i.data.status !== 'Cancelada').reduce((s, i) => s + (i.data.total || 0), 0);
              const totalPaid = invoices.filter(i => i.data.status === 'Pagada').reduce((s, i) => s + (i.data.total || 0), 0);
              const totalPending = invoices.filter(i => i.data.status === 'Enviada' || i.data.status === 'Borrador').reduce((s, i) => s + (i.data.total || 0), 0);
              const totalOverdue = invoices.filter(i => i.data.status === 'Vencida').reduce((s, i) => s + (i.data.total || 0), 0);
              return [
                { lbl: 'Facturado', val: fmtCOP(totalInvoiced), color: 'text-[var(--af-accent)]' },
                { lbl: 'Pagado', val: fmtCOP(totalPaid), color: 'text-emerald-400' },
                { lbl: 'Pendiente', val: fmtCOP(totalPending), color: 'text-blue-400' },
                { lbl: 'Vencido', val: fmtCOP(totalOverdue), color: 'text-red-400' },
              ].map((c, i) => (
                <div key={i} className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-3">
                  <div className={`text-lg font-bold ${c.color}`}>{c.val}</div>
                  <div className="text-[11px] text-[var(--muted-foreground)]">{c.lbl}</div>
                </div>
              ));
            })()}
          </div>
          {/* Invoice List */}
          {(() => {
            const filtered = invoices.filter(i => invoiceFilterStatus === 'all' || i.data.status === invoiceFilterStatus);
            return filtered.length === 0 ? <div className="text-center py-16 text-[var(--af-text3)]"><div className="text-4xl mb-3">🧾</div><div className="text-sm">Sin facturas</div></div> : (
              <div className="space-y-2">
                {filtered.map(inv => {
                  const statusColors: Record<string, string> = { Borrador: 'bg-[var(--af-bg4)] text-[var(--muted-foreground)]', Enviada: 'bg-blue-500/10 text-blue-400', Pagada: 'bg-emerald-500/10 text-emerald-400', Vencida: 'bg-red-500/10 text-red-400', Cancelada: 'bg-red-500/5 text-red-300 line-through' };
                  return (<div key={inv.id} className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:border-[var(--input)] transition-all">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-semibold">{inv.data.number}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors[inv.data.status] || ''}`}>{inv.data.status}</span>
                      </div>
                      <div className="text-xs text-[var(--muted-foreground)]">{inv.data.projectName}{inv.data.clientName ? ' · ' + inv.data.clientName : ''}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-lg font-bold text-[var(--af-accent)]">{fmtCOP(inv.data.total)}</div>
                      <div className="text-[10px] text-[var(--muted-foreground)]">{inv.data.issueDate}{inv.data.dueDate ? ' → ' + inv.data.dueDate : ''}</div>
                    </div>
                    <div className="flex gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                      {inv.data.status === 'Borrador' && <button className="px-2 py-1.5 rounded text-xs cursor-pointer bg-blue-500/10 text-blue-400 hover:bg-blue-500/20" onClick={() => { getFirebase().firestore().collection('invoices').doc(inv.id).update({ status: 'Enviada' }); showToast('Factura enviada'); }}>Enviar</button>}
                      {inv.data.status === 'Enviada' && <button className="px-2 py-1.5 rounded text-xs cursor-pointer bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20" onClick={() => { getFirebase().firestore().collection('invoices').doc(inv.id).update({ status: 'Pagada' }); showToast('Factura pagada'); }}>Pagar</button>}
                      {inv.data.status === 'Enviada' && <button className="px-2 py-1.5 rounded text-xs cursor-pointer bg-red-500/10 text-red-400 hover:bg-red-500/20" onClick={() => { getFirebase().firestore().collection('invoices').doc(inv.id).update({ status: 'Vencida' }); showToast('Factura vencida'); }}>Vencer</button>}
                      <button className="px-2 py-1.5 rounded text-xs cursor-pointer bg-red-500/10 text-red-400 hover:bg-red-500/20" onClick={() => { if (confirm('Eliminar factura?')) { getFirebase().firestore().collection('invoices').doc(inv.id).delete().then(() => showToast('Factura eliminada')); } }}>🗑</button>
                    </div>
                  </div>);
                })}
              </div>
            );
          })()}
        </div>)}

        {invoiceTab === 'create' && (<div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[15px] font-semibold">Nueva Factura</h3>
            <button className="text-xs text-[var(--muted-foreground)] cursor-pointer hover:underline" onClick={() => setInvoiceTab('list')}>Cancelar</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <select className="bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-3 py-2 text-sm text-[var(--foreground)] outline-none" value={forms.invProject || ''} onChange={e => setForms(p => ({ ...p, invProject: e.target.value }))}>
              <option value="">Seleccionar proyecto</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.data.name}</option>)}
            </select>
            <input type="text" className="bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-3 py-2 text-sm text-[var(--foreground)] outline-none" placeholder="Numero de factura" value={forms.invNumber || ''} onChange={e => setForms(p => ({ ...p, invNumber: e.target.value }))} />
            <input type="date" className="bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-3 py-2 text-sm text-[var(--foreground)] outline-none" value={forms.invIssueDate || ''} onChange={e => setForms(p => ({ ...p, invIssueDate: e.target.value }))} />
            <input type="date" className="bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-3 py-2 text-sm text-[var(--foreground)] outline-none" value={forms.invDueDate || ''} onChange={e => setForms(p => ({ ...p, invDueDate: e.target.value }))} />
          </div>
          {/* Items */}
          <div className="space-y-2">
            <div className="flex items-center justify-between"><span className="text-[13px] font-medium">Items</span><button className="text-xs text-[var(--af-accent)] cursor-pointer hover:underline" onClick={addInvoiceItem}>+ Agregar item</button></div>
            <div className="bg-[var(--af-bg3)] rounded-lg p-3 space-y-2">
              <div className="grid grid-cols-12 gap-2 text-[11px] text-[var(--muted-foreground)] font-medium">
                <div className="col-span-4">Concepto</div><div className="col-span-3">Fase</div><div className="col-span-2">Horas</div><div className="col-span-2">Tarifa</div><div className="col-span-1"></div>
              </div>
              {invoiceItems.map((item, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                  <input className="col-span-4 bg-[var(--card)] border border-[var(--border)] rounded px-2 py-1.5 text-xs outline-none" placeholder="Concepto" value={item.concept} onChange={e => updateInvoiceItem(idx, 'concept', e.target.value)} />
                  <select className="col-span-3 bg-[var(--card)] border border-[var(--border)] rounded px-2 py-1.5 text-xs outline-none" value={item.phase} onChange={e => updateInvoiceItem(idx, 'phase', e.target.value)}>
                    <option value="">Fase</option>
                    {DEFAULT_PHASES.map(ph => <option key={ph} value={ph}>{ph}</option>)}
                  </select>
                  <input type="number" className="col-span-2 bg-[var(--card)] border border-[var(--border)] rounded px-2 py-1.5 text-xs outline-none text-right" value={item.hours} onChange={e => updateInvoiceItem(idx, 'hours', e.target.value)} />
                  <input type="number" className="col-span-2 bg-[var(--card)] border border-[var(--border)] rounded px-2 py-1.5 text-xs outline-none text-right" value={item.rate} onChange={e => updateInvoiceItem(idx, 'rate', e.target.value)} />
                  <button className="col-span-1 text-xs text-red-400 cursor-pointer text-center" onClick={() => removeInvoiceItem(idx)}>✕</button>
                </div>
              ))}
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-[var(--muted-foreground)]">Subtotal</span>
              <span>{fmtCOP(invoiceItems.reduce((s, i) => s + (Number(i.amount) || 0), 0))}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--muted-foreground)]">IVA (%)</span>
              <input type="number" className="w-20 bg-[var(--af-bg3)] border border-[var(--border)] rounded px-2 py-1 text-xs text-right outline-none" value={forms.invTax || 19} onChange={e => setForms(p => ({ ...p, invTax: e.target.value }))} />
            </div>
            <div className="flex justify-between items-center text-sm font-semibold">
              <span>Total</span>
              <span className="text-[var(--af-accent)]">{fmtCOP(invoiceItems.reduce((s, i) => s + (Number(i.amount) || 0), 0) * (1 + (Number(forms.invTax) || 19) / 100))}</span>
            </div>
          </div>
          <textarea className="w-full bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-3 py-2 text-sm text-[var(--foreground)] outline-none resize-none" rows={2} placeholder="Notas..." value={forms.invNotes || ''} onChange={e => setForms(p => ({ ...p, invNotes: e.target.value }))} />
          <button className="w-full bg-[var(--af-accent)] text-background px-4 py-2.5 rounded-lg text-sm font-semibold cursor-pointer border-none hover:bg-[var(--af-accent2)]" onClick={saveInvoice}>Crear Factura</button>
        </div>)}
      </div>
  );
}
