'use client';
import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { fmtRecTime, fmtSize as fmtFileSize } from '@/lib/helpers';

export default function ChatScreen() {
  const {
    audioPreviewBlobRef, audioPreviewDuration, audioPreviewUrl, audioProgress, authUser,
    chatDmUser, chatDropActive, chatMobileShow, chatProjectId, fileIcon,
    fileInputRef, forms, handleFileSelect, handleMicButton, isRecording,
    messages, pendingFiles, playingAudio, projects, recDuration,
    recVolume, removePendingFile, sendAll, setAudioPreviewDuration, setAudioPreviewUrl,
    setChatDmUser, setChatDropActive, setChatMobileShow, setChatProjectId, setForms,
    setShowEmojiPicker, showEmojiPicker, stopRecording, teamUsers, toggleAudioPlay,
    userName,
  } = useApp();

  return (
<div className="animate-fadeIn flex flex-col md:h-full pb-[calc(60px+env(safe-area-inset-bottom,0px))] md:pb-0" style={{ minHeight: 0, flex: 1 }}>

            {/* Lista de conversaciones */}
            <div className={`${chatMobileShow ? 'hidden' : 'flex'} flex-col flex-1 md:w-[260px] md:flex-shrink-0 border-r border-[var(--border)] overflow-y-auto bg-[var(--card)] md:bg-transparent`}>
              <div className="p-3 border-b border-[var(--border)]">
                <div className="relative">
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none flex-shrink-0 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                  <input className="w-full bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg pl-8 pr-3 py-2 text-[13px] text-[var(--foreground)] outline-none focus:border-[var(--af-accent)]" placeholder="Buscar conversaciones..." value={forms.chatSearch || ''} onChange={e => setForms(p => ({ ...p, chatSearch: e.target.value }))} />
                </div>
              </div>
              {/* Chat General */}
              <div className={`p-3.5 border-b border-[var(--border)] cursor-pointer transition-colors ${chatProjectId === '__general__' ? 'bg-[var(--accent)] border-r-2 border-r-[var(--af-accent)]' : 'hover:bg-[var(--af-bg3)]'}`} onClick={() => { setChatProjectId('__general__'); setChatDmUser(null); setChatMobileShow(true); setShowEmojiPicker(false); }}>
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[var(--af-accent)] to-purple-500 flex items-center justify-center text-base flex-shrink-0">💬</div>
                  <div className="min-w-0">
                    <div className="text-[13px] font-semibold">Chat General</div>
                    <div className="text-[11px] text-[var(--af-text3)] truncate">Canal de todo el equipo</div>
                  </div>
                </div>
              </div>
              {/* Colaboradores (DM) */}
              {teamUsers.length > 0 && (<div className="mt-1">
                <div className="px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)]">Colaboradores ({teamUsers.length})</div>
                {teamUsers.filter(u => u.id !== authUser?.uid && (!forms.chatSearch || u.data.name.toLowerCase().includes((forms.chatSearch || '').toLowerCase()) || (u.data.email || '').toLowerCase().includes((forms.chatSearch || '').toLowerCase()))).map(u => (
                  <div key={u.id} className={`flex items-center gap-2.5 px-3.5 py-2.5 border-b border-[var(--border)] cursor-pointer transition-colors ${chatDmUser === u.id && chatProjectId === '__dm__' ? 'bg-[var(--accent)] border-r-2 border-r-[var(--af-accent)]' : 'hover:bg-[var(--af-bg3)]'}`} onClick={() => { setChatProjectId('__dm__'); setChatDmUser(u.id); setChatMobileShow(true); setShowEmojiPicker(false); }}>
                    <div className="w-9 h-9 rounded-full bg-[var(--af-bg3)] flex items-center justify-center text-[13px] font-bold flex-shrink-0" style={{ background: u.data.photoURL ? undefined : `hsl(${(u.id.charCodeAt(0) * 37) % 360}, 55%, 45%)`, color: u.data.photoURL ? undefined : '#fff' }}>{u.data.photoURL ? <img src={u.data.photoURL} alt="" className="w-full h-full rounded-full object-cover" /> : (u.data.name || u.data.email || '?')[0].toUpperCase()}</div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] font-medium truncate">{u.data.name || u.data.email}</div>
                      <div className="text-[11px] text-[var(--af-text3)] truncate">{u.data.role || 'Miembro'}</div>
                    </div>
                  </div>
                ))}
              </div>)}
              {/* Project chats */}
              {projects.length > 0 && (<div className="mt-1">
                <div className="px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)]">Proyectos ({projects.length})</div>
                {projects.filter(p => !forms.chatSearch || p.data.name.toLowerCase().includes((forms.chatSearch || '').toLowerCase())).map(p => (
                  <div key={p.id} className={`p-3.5 border-b border-[var(--border)] cursor-pointer transition-colors ${p.id === chatProjectId && chatProjectId !== '__general__' && chatProjectId !== '__dm__' ? 'bg-[var(--accent)] border-r-2 border-r-[var(--af-accent)]' : 'hover:bg-[var(--af-bg3)]'}`} onClick={() => { setChatProjectId(p.id); setChatDmUser(null); setChatMobileShow(true); setShowEmojiPicker(false); }}>
                    <div className="text-[13px] font-medium">{p.data.name}</div>
                    <div className="text-[11px] text-[var(--af-text3)] truncate">{p.data.client ? 'Cliente: ' + p.data.client : 'Canal del equipo'}</div>
                  </div>
                ))}
              </div>)}
            </div>

            {/* Area de mensajes */}
            <div className={`${chatMobileShow ? 'flex' : 'hidden'} md:flex flex-col flex-1 min-h-0 overflow-hidden bg-background`}>
              <div className="flex items-center gap-2 p-3 border-b border-[var(--border)] flex-shrink-0 bg-[var(--card)]">
                <button className="w-11 h-11 rounded-lg flex items-center justify-center cursor-pointer hover:bg-[var(--af-bg3)]" onClick={() => { setChatMobileShow(false); setShowEmojiPicker(false); }}>
                  <svg viewBox="0 0 24 24" className="w-4 h-4" style={{stroke:'currentColor',fill:'none'}} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold truncate">{chatProjectId === '__general__' ? '💬 Chat General' : chatProjectId === '__dm__' ? (() => { const u = teamUsers.find(x => x.id === chatDmUser); return (u?.data.name || u?.data.email || 'Chat directo'); })() : projects.find(p => p.id === chatProjectId)?.data.name || 'Selecciona un proyecto'}</div>
                  <div className="text-[10px] text-[var(--muted-foreground)]">{chatProjectId === '__general__' ? 'Canal de todo el equipo' : chatProjectId === '__dm__' ? (() => { const u = teamUsers.find(x => x.id === chatDmUser); return u?.data.role || 'Colaborador'; })() : chatProjectId ? 'Canal del equipo' : ''}</div>
                </div>
              </div>

              <div id="chat-msgs" className="flex-1 min-h-0 overflow-y-auto p-4 flex flex-col gap-3"
                onDragOver={(e) => { e.preventDefault(); setChatDropActive(true); }}
                onDragLeave={() => setChatDropActive(false)}
                onDrop={(e) => { e.preventDefault(); setChatDropActive(false); if (e.dataTransfer.files) handleFileSelect(e.dataTransfer.files); }}
                onPaste={(e) => { const items = e.clipboardData?.items; if (items) { const imgs: File[] = []; for (let i = 0; i < items.length; i++) { if (items[i].type.startsWith('image/')) { const f = items[i].getAsFile(); if (f) imgs.push(f); } } if (imgs.length > 0) { e.preventDefault(); handleFileSelect(imgs as unknown as FileList); } } }}
              >
                {chatDropActive && (<div className="absolute inset-0 z-10 flex items-center justify-center bg-[var(--af-accent)]/5 border-2 border-dashed border-[var(--af-accent)]/40 rounded-xl m-4"><div className="text-center"><div className="text-4xl mb-2">📎</div><div className="text-sm font-medium text-[var(--af-accent)]">Suelta archivos aquí</div></div></div>)}
                {messages.length === 0 ? <div className="text-center py-10 text-[var(--af-text3)] text-[13px]">{chatProjectId === '__dm__' ? 'Inicia una conversación directa' : 'Sin mensajes. ¡Saluda al equipo!'}</div> :
                messages.map(m => {
                  const isMe = m.uid === authUser?.uid;
                  const ts = m.createdAt?.toDate ? m.createdAt.toDate() : new Date();
                  const msgType = m.type || 'TEXT';
                  return (<div key={m.id} className={`max-w-[80%] ${isMe ? 'self-end' : ''}`}>
                    <div className={`text-[10px] text-[var(--af-text3)] mb-1 ${isMe ? 'text-right' : ''}`}>{isMe ? 'Tú' : (m.userName || 'Equipo')} · {ts.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}</div>
                    {msgType === 'TEXT' && m.text && (<div className={`px-3 py-2.5 text-[13px] leading-relaxed ${isMe ? 'bg-[var(--accent)] text-[var(--af-accent2)] border border-[var(--af-accent)]/20 rounded-xl rounded-br-sm' : 'bg-[var(--af-bg3)] text-[var(--foreground)] rounded-xl rounded-bl-sm'}`}>{m.text.split('\n').map((l: string, i: number) => <span key={i}>{l}<br /></span>)}</div>)}
                    {msgType === 'AUDIO' && m.audioData && (<div className={`flex items-center gap-2.5 px-3 py-2.5 ${isMe ? 'bg-[var(--accent)] border border-[var(--af-accent)]/20 rounded-xl rounded-br-sm' : 'bg-[var(--af-bg3)] rounded-xl rounded-bl-sm'}`}>
                      <audio id={'audio-' + m.id} src={m.audioData} preload="metadata" className="hidden" />
                      <button className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 cursor-pointer border-none transition-transform active:scale-95" style={{ background: playingAudio === m.id ? 'var(--af-accent)' : 'var(--af-bg4)' }} onClick={() => toggleAudioPlay(m.id)}>
                        {playingAudio === m.id ? (<svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>) : (<svg className="w-3.5 h-3.5 ml-0.5" fill="currentColor" viewBox="0 0 24 24"><polygon points="5,3 19,12 5,21"/></svg>)}
                      </button>
                      <div className="flex-1 min-w-0"><div className="flex gap-0.5 items-end h-5">{Array.from({ length: 28 }).map((_, i) => (<div key={i} className="w-[3px] rounded-full transition-all duration-100" style={{ height: (i % 3 === 0 ? '6px' : i % 3 === 1 ? '12px' : '18px'), backgroundColor: playingAudio === m.id && ((i / 28) * 100 <= audioProgress) ? 'var(--af-accent)' : 'var(--border)' }} />))}</div><div className="text-[10px] text-[var(--muted-foreground)] mt-0.5">{m.audioDuration ? fmtRecTime(m.audioDuration) : '0:00'}</div></div>
                      <div className="text-[9px]">🎙️</div>
                    </div>)}
                    {msgType === 'IMAGE' && m.fileData && (<div className={`rounded-xl overflow-hidden ${isMe ? 'border border-[var(--af-accent)]/20' : 'border border-[var(--border)]'}`}><img src={m.fileData} alt={m.fileName || 'Imagen'} className="max-w-full max-h-[300px] object-cover cursor-pointer rounded-xl" onClick={() => { if (m.fileData) { const w = window.open(''); if (w) w.document.write(`<img src="${m.fileData}" style="max-width:100vw;max-height:100vh;" />`); } }} />{m.fileName && <div className="text-[10px] text-[var(--muted-foreground)] px-2 py-1 bg-[var(--af-bg3)]">{m.fileName}{m.fileSize ? ` · ${fmtFileSize(m.fileSize)}` : ''}</div>}</div>)}
                    {msgType === 'FILE' && m.fileData && (<div className={`flex items-center gap-3 px-3 py-2.5 rounded-xl ${isMe ? 'bg-[var(--accent)] border border-[var(--af-accent)]/20' : 'bg-[var(--af-bg3)] border border-[var(--border)]'}`}>
                      <div className="text-2xl flex-shrink-0">{fileIcon(m.fileType || '')}</div>
                      <div className="flex-1 min-w-0"><div className="text-[13px] font-medium truncate">{m.fileName || 'Archivo'}</div>{m.fileSize && <div className="text-[10px] text-[var(--muted-foreground)]">{fmtFileSize(m.fileSize)}</div>}</div>
                      <a href={m.fileData} download={m.fileName || 'archivo'} className="w-8 h-8 rounded-lg flex items-center justify-center bg-[var(--af-bg4)] hover:bg-[var(--af-accent)]/10 transition-colors flex-shrink-0" title="Descargar"><svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></a>
                    </div>)}
                  </div>);
                })}
              </div>
              {isRecording && (<div className="flex-shrink-0 px-4 py-2.5 border-t border-[var(--border)] bg-red-500/5 flex items-center gap-3"><div className="flex items-end gap-[3px]">{[recVolume * 28 + 4, recVolume * 22 + 6, recVolume * 32 + 3, recVolume * 18 + 5].map((h, i) => (<div key={i} className="w-[3px] bg-red-500 rounded-full animate-pulse" style={{ height: `${Math.max(h, 4)}px` }} />))}</div><span className="text-[13px] text-red-500 font-mono font-medium">{fmtRecTime(recDuration)}</span><button className="ml-auto text-[11px] px-3 py-1 rounded-full bg-red-500 text-white font-semibold cursor-pointer border-none" onClick={async () => { const blob = await stopRecording(); if (blob) { const url = URL.createObjectURL(blob); setAudioPreviewUrl(url); setAudioPreviewDuration(recDuration); audioPreviewBlobRef.current = blob; } }}>Detener</button></div>)}
              {audioPreviewUrl && !isRecording && (<div className="flex-shrink-0 px-4 py-2.5 border-t border-[var(--border)] bg-[var(--af-accent)]/5 flex items-center gap-3"><div className="text-[20px]">🎙️</div><div className="flex-1 min-w-0"><div className="text-[12px] font-medium text-[var(--muted-foreground)]">Nota de voz ({fmtRecTime(audioPreviewDuration)})</div></div><button className="text-[11px] px-3 py-1 rounded-full border border-red-500/30 text-red-400 hover:bg-red-500/10 cursor-pointer bg-transparent" onClick={() => { setAudioPreviewUrl(null); audioPreviewBlobRef.current = null; }}>Descartar</button></div>)}
              {pendingFiles.length > 0 && (<div className="flex-shrink-0 px-4 py-2.5 border-t border-[var(--border)] bg-[var(--af-bg3)]"><div className="flex gap-2 overflow-x-auto pb-1">{pendingFiles.map(f => (<div key={f.id} className="flex-shrink-0 w-[72px] h-[72px] rounded-lg border border-[var(--border)] bg-[var(--card)] p-1 relative overflow-hidden">{f.preview ? <img src={f.preview} className="w-full h-full object-cover rounded" alt="" /> : <div className="w-full h-full flex items-center justify-center text-2xl">{fileIcon(f.type)}</div>}<button className="absolute -top-2 -right-2 w-7 h-7 bg-red-500 text-white rounded-full text-[11px] flex items-center justify-center cursor-pointer border-none leading-none" onClick={() => removePendingFile(f.id)}>✕</button><div className="absolute bottom-0 inset-x-0 bg-black/50 text-[8px] text-white truncate px-0.5 py-px">{f.name}</div></div>))}</div></div>)}
              {/* Emoji Picker */}
              {showEmojiPicker && (<div className="flex-shrink-0 border-t border-[var(--border)] bg-[var(--card)] px-2 py-2 animate-fadeIn" style={{ animationDuration: '0.15s' }}>
                <div className="flex gap-1 mb-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
                  {['😀','😍','😂','🤣','😊','🥰','😎','🤩','🥳','😤','😢','😭','🤔','🤯','😱','🥺','😤','🙄','😴','🤮','👍','👎','👋','🤝','✌️','🤞','👏','🙏','💪','✅','❌','⭐','🔥','❤️','💯','🎉','🏗️','📐','🏠','💎','🔧','📋','📎','📌','⏰','📅','💰','🎨','💡','🚧','🏗️','🏠','🏢','🏗️','⚡'].map((e, i) => (
                    <button key={i} className="w-[34px] h-[34px] flex items-center justify-center rounded-lg hover:bg-[var(--af-bg3)] transition-colors cursor-pointer border-none bg-transparent text-[18px] flex-shrink-0" onClick={() => { setForms(p => ({ ...p, chatInput: (p.chatInput || '') + e })); document.getElementById('chat-input-field')?.focus(); }}>{e}</button>
                  ))}
                </div>
                <div className="text-center"><button className="text-[11px] text-[var(--muted-foreground)] hover:text-[var(--foreground)] cursor-pointer border-none bg-transparent" onClick={() => setShowEmojiPicker(false)}>Cerrar</button></div>
              </div>)}
              <div className="flex-shrink-0 border-t border-[var(--border)] bg-[var(--card)]">
                <div className="flex gap-1.5 items-end px-2.5 py-2.5 safe-bottom">
                  <input ref={fileInputRef} type="file" className="hidden" multiple onChange={(e) => handleFileSelect(e.target.files)} accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.rar,.dwg,.txt,.csv" />
                  <button className="w-9 h-9 rounded-full flex items-center justify-center cursor-pointer border-none bg-transparent hover:bg-[var(--af-bg3)] transition-colors flex-shrink-0" onClick={() => fileInputRef.current?.click()} title="Adjuntar archivo"><svg viewBox="0 0 24 24" className="w-[18px] h-[18px] stroke-[var(--muted-foreground)] fill-none" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49 0L2 12.05"/><circle cx="17" cy="5" r="3"/></svg></button>
                  <input id="chat-input-field" className="flex-1 bg-[var(--af-bg3)] border border-[var(--border)] rounded-full px-4 py-2.5 text-[16px] text-[var(--foreground)] outline-none focus:border-[var(--input)] min-w-0" placeholder="Escribe un mensaje..." value={forms.chatInput || ''} onChange={e => setForms(p => ({ ...p, chatInput: e.target.value }))} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendAll(); } }} />
                  <button className="w-9 h-9 rounded-full flex items-center justify-center cursor-pointer border-none bg-transparent hover:bg-[var(--af-bg3)] transition-colors flex-shrink-0" onClick={() => setShowEmojiPicker(p => !p)} title="Emojis"><span className="text-[18px]" role="img" aria-label="emojis">😀</span></button>
                  <button className={`w-9 h-9 rounded-full flex items-center justify-center cursor-pointer border-none flex-shrink-0 transition-all ${isRecording ? 'bg-red-500 animate-pulse' : audioPreviewUrl ? 'bg-[var(--af-accent)]' : 'bg-transparent hover:bg-[var(--af-bg3)]'}`} onClick={handleMicButton} title={isRecording ? 'Detener grabación' : audioPreviewUrl ? 'Descartar nota' : 'Grabar nota de voz'}>
                    {isRecording ? (<div className="w-3 h-3 bg-white rounded-sm" />) : (<svg viewBox="0 0 24 24" className="w-[18px] h-[18px]" fill={audioPreviewUrl ? 'var(--background)' : 'none'} stroke={audioPreviewUrl ? 'none' : 'currentColor'} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/><path d="M19 10v2a7 7 0 01-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>)}
                  </button>
                  <button className="w-9 h-9 rounded-full bg-[var(--af-accent)] flex items-center justify-center cursor-pointer border-none flex-shrink-0 active:scale-95 transition-transform" onClick={sendAll} title="Enviar"><svg viewBox="0 0 24 24" className="w-4 h-4 stroke-background fill-none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button>
                </div>
              </div>
            </div>
          </div>
  );
}
