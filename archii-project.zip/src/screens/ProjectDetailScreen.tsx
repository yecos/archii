'use client';
import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { fmtCOP, fmtDate, fmtSize, statusColor, prioColor, taskStColor } from '@/lib/helpers';

export default function ProjectDetailScreen() {
  const {
    approvals, calcGanttDays, calcGanttOffset, currentProject, deleteApproval,
    deleteExpense, deleteFile, deleteFromOneDrive, deleteTask, doMicrosoftLogin,
    downloadOneDriveFile, formatFileSize, forms, galleryLoading, getFileIcon,
    getUserName, handleDroppedFiles, handleFileUpload, initDefaultPhases, loadGalleryPhotos,
    loadOneDriveFiles, loading, msAccessToken, msConnected, msLoading,
    navigateToFolder, odBreadcrumbs, odCurrentFolder, odDragOver, odGalleryPhotos,
    odProjectFolder, odRenameName, odRenaming, odSearchQuery, odSearchResults,
    odSearching, odTab, odUploadFile, odUploadProgress, odUploading,
    odViewMode, oneDriveFiles, openEditTask, openModal, openOneDriveForProject,
    projectBudget, projectExpenses, projectFiles, projectSpent, projectTasks,
    renameOneDriveFile, searchOneDriveFiles, selectedProjectId, setForms, setLightboxIndex,
    setLightboxPhoto, setOdBreadcrumbs, setOdCurrentFolder, setOdDragOver, setOdRenameName,
    setOdRenaming, setOdSearchQuery, setOdSearchResults, setOdTab, setOdViewMode,
    setOneDriveFiles, setShowOneDrive, showOneDrive, timeAgo, toggleTask,
    updateApproval, updatePhaseStatus, updateProjectProgress, uploadFile, workPhases,
  } = useApp();

  if (!currentProject) return null;

  return (
<div className="animate-fadeIn space-y-4">
            <div className="bg-gradient-to-br from-[var(--card)] to-[var(--af-bg3)] border border-[var(--border)] rounded-xl p-5 md:p-6 relative overflow-hidden">
              <div className="absolute -right-8 -top-8 w-44 h-44 border-[40px] border-[var(--af-accent)]/5 rounded-full" />
              <div className="flex items-start justify-between flex-wrap gap-3">
                <div>
                  <span className={`text-[11px] px-2 py-0.5 rounded-full ${statusColor(currentProject.data.status)}`}>{currentProject.data.status}</span>
                  <div style={{ fontFamily: "'DM Serif Display', serif" }} className="text-2xl mt-2">{currentProject.data.name}</div>
                  <div className="text-sm text-[var(--muted-foreground)] mt-1">{currentProject.data.location && '📍 ' + currentProject.data.location}{currentProject.data.client ? ' · ' + currentProject.data.client : ''}</div>
                  {currentProject.data.description && <div className="text-sm text-[var(--muted-foreground)] mt-3 max-w-xl">{currentProject.data.description}</div>}
                </div>
                <div className="flex gap-3">
                  <div className="text-center"><div className="text-lg font-semibold text-[var(--af-accent)]">{fmtCOP(currentProject.data.budget)}</div><div className="text-[10px] text-[var(--af-text3)]">Presupuesto</div></div>
                  <div className="text-center"><div className="text-lg font-semibold text-emerald-400">{fmtCOP(projectSpent)}</div><div className="text-[10px] text-[var(--af-text3)]">Gastado</div></div>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-3">
                <div className="flex-1 h-2 bg-[var(--af-bg4)] rounded-full overflow-hidden"><div className={`h-full rounded-full ${(currentProject.data.progress || 0) >= 80 ? 'bg-emerald-500' : (currentProject.data.progress || 0) >= 40 ? 'bg-[var(--af-accent)]' : 'bg-amber-500'}`} style={{ width: (currentProject.data.progress || 0) + '%' }} /></div>
                <input type="number" min="0" max="100" className="w-14 bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-2 py-1 text-sm text-[var(--foreground)] outline-none text-center focus:border-[var(--af-accent)]" value={currentProject.data.progress || 0} onChange={e => { const v = Math.min(100, Math.max(0, Number(e.target.value) || 0)); updateProjectProgress(v); }} />
                <span className="text-sm font-medium text-[var(--muted-foreground)]">%</span>
              </div>
              {projectBudget > 0 && <div className="mt-3 text-xs text-[var(--muted-foreground)]">{projectSpent > projectBudget ? <span className="text-red-400 font-medium">⚠️ Excedido por {fmtCOP(projectSpent - projectBudget)}</span> : `Restante: ${fmtCOP(projectBudget - projectSpent)} (${Math.round((projectSpent / projectBudget) * 100)}% del presupuesto)`}</div>}
            </div>

            {/* Tabs */}
            <div className="flex gap-1 bg-[var(--af-bg3)] rounded-lg p-1 w-fit overflow-x-auto -mx-1 px-1 scrollbar-none">
              {['Resumen', 'Tareas', 'Presupuesto', 'Archivos', 'Obra', 'Portal'].map(tab => (
                <button key={tab} className={`px-3 py-1.5 rounded-md text-[13px] cursor-pointer transition-all ${forms.detailTab === tab ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)] hover:text-[var(--foreground)]'}`} onClick={() => setForms(p => ({ ...p, detailTab: tab }))}>{tab}</button>
              ))}
            </div>

            {/* Tab: Resumen */}
            {forms.detailTab === 'Resumen' && (<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5">
                <div className="text-[15px] font-semibold mb-4">Información</div>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Cliente</span><span>{currentProject.data.client || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Ubicación</span><span>{currentProject.data.location || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Inicio</span><span>{currentProject.data.startDate || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Entrega</span><span>{currentProject.data.endDate || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-[var(--muted-foreground)]">Presupuesto</span><span className="text-[var(--af-accent)] font-semibold">{fmtCOP(currentProject.data.budget)}</span></div>
                </div>
              </div>
              <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5">
                <div className="text-[15px] font-semibold mb-4">Actividad reciente</div>
                {projectTasks.filter(t => t.data.status !== 'Completado').slice(0, 5).map(t => (
                  <div key={t.id} className="flex items-center gap-3 py-2 border-b border-[var(--border)] last:border-0">
                    <div className={`w-2 h-2 rounded-full ${t.data.priority === 'Alta' ? 'bg-red-500' : t.data.priority === 'Media' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                    <div className="flex-1 text-sm truncate">{t.data.title}</div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${taskStColor(t.data.status)}`}>{t.data.status}</span>
                  </div>
                ))}
                {projectTasks.filter(t => t.data.status !== 'Completado').length === 0 && <div className="text-center py-6 text-[var(--af-text3)] text-sm">Sin tareas pendientes</div>}
              </div>
            </div>)}

            {/* Tab: Tareas */}
            {forms.detailTab === 'Tareas' && (<div>
              <div className="flex justify-between items-center mb-4">
                <div className="text-sm text-[var(--muted-foreground)]">{projectTasks.length} tareas en este proyecto</div>
                <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border-none" onClick={() => { setForms(p => ({ ...p, taskTitle: '', taskProject: selectedProjectId, taskDue: new Date().toISOString().split('T')[0] })); openModal('task'); }}>+ Nueva tarea</button>
              </div>
              {projectTasks.length === 0 ? <div className="text-center py-12 text-[var(--af-text3)]"><div className="text-3xl mb-2">✅</div><div className="text-sm">Sin tareas en este proyecto</div></div> :
              projectTasks.map(t => (
                <div key={t.id} className="flex items-start gap-3 py-3 border-b border-[var(--border)] last:border-0">
                  <div className={`w-2 h-2 rounded-full mt-1.5 ${t.data.priority === 'Alta' ? 'bg-red-500' : t.data.priority === 'Media' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                  <div className="w-4 h-4 rounded border border-[var(--input)] flex-shrink-0 mt-0.5 cursor-pointer flex items-center justify-center hover:border-[var(--af-accent)] ${t.data.status === 'Completado' ? 'bg-emerald-500 border-emerald-500' : ''}" onClick={() => toggleTask(t.id, t.data.status)}>{t.data.status === 'Completado' && <span className="text-white text-[10px] font-bold">✓</span>}</div>
                  <div className="flex-1 min-w-0">
                    <div className={`text-[13.5px] font-medium ${t.data.status === 'Completado' ? 'line-through text-[var(--af-text3)]' : ''}`}>{t.data.title}</div>
                    <div className="text-[11px] text-[var(--af-text3)] mt-1 flex items-center gap-2 flex-wrap">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${prioColor(t.data.priority)}`}>{t.data.priority}</span>
                      {t.data.dueDate && <span>📅 {fmtDate(t.data.dueDate)}</span>}
                      {t.data.assigneeId && <span>👤 {getUserName(t.data.assigneeId)}</span>}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${taskStColor(t.data.status)}`}>{t.data.status}</span>
                  <button className="text-xs px-1.5 py-0.5 rounded bg-[var(--af-accent)]/10 text-[var(--af-accent)] cursor-pointer hover:bg-[var(--af-accent)]/20" onClick={() => openEditTask(t)}>✎</button>
                  <button className="text-xs px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer hover:bg-red-500/20" onClick={() => deleteTask(t.id)}>✕</button>
                </div>
              ))}
            </div>)}

            {/* Tab: Presupuesto */}
            {forms.detailTab === 'Presupuesto' && (<div>
              <div className="flex justify-between items-center mb-4">
                <div className="text-sm text-[var(--muted-foreground)]">{projectExpenses.length} gastos · Total: <span className="text-[var(--af-accent)] font-semibold">{fmtCOP(projectSpent)}</span> {projectBudget > 0 && <span>de {fmtCOP(projectBudget)}</span>}</div>
                <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border-none" onClick={() => { setForms(p => ({ ...p, expConcept: '', expProject: selectedProjectId, expAmount: '', expDate: new Date().toISOString().split('T')[0], expCategory: 'Materiales' })); openModal('expense'); }}>+ Registrar gasto</button>
              </div>
              {projectBudget > 0 && <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 mb-4">
                <div className="flex justify-between text-sm mb-2"><span className="text-[var(--muted-foreground)]">Presupuesto utilizado</span><span className="font-semibold">{Math.min(100, Math.round((projectSpent / projectBudget) * 100))}%</span></div>
                <div className="h-2 bg-[var(--af-bg4)] rounded-full overflow-hidden"><div className={`h-full rounded-full ${projectSpent > projectBudget ? 'bg-red-500' : projectSpent > projectBudget * 0.8 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: Math.min(100, (projectSpent / projectBudget) * 100) + '%' }} /></div>
              </div>}
              {projectExpenses.length === 0 ? <div className="text-center py-12 text-[var(--af-text3)]"><div className="text-3xl mb-2">💰</div><div className="text-sm">Sin gastos registrados</div></div> :
              <div className="space-y-2">
                {projectExpenses.map(e => (
                  <div key={e.id} className="flex items-center gap-3 py-2.5 px-3 bg-[var(--card)] border border-[var(--border)] rounded-lg">
                    <div className="flex-1 min-w-0"><div className="text-sm font-medium">{e.data.concept}</div><div className="text-[11px] text-[var(--af-text3)]">{e.data.category} · {e.data.date}</div></div>
                    <div className="text-sm font-semibold text-[var(--af-accent)]">{fmtCOP(e.data.amount)}</div>
                    <button className="text-xs px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer" onClick={() => deleteExpense(e.id)}>✕</button>
                  </div>
                ))}
              </div>}
            </div>)}

            {/* Tab: Archivos */}
            {forms.detailTab === 'Archivos' && (<div>
              {/* OneDrive Section */}
              {!msConnected ? (
                <div className="mb-4 bg-[#0078d4]/10 border border-[#0078d4]/20 rounded-xl p-6 text-center">
                  <div className="text-[40px] mb-3">☁️</div>
                  <div className="text-[15px] font-semibold mb-1">Conectar OneDrive</div>
                  <div className="text-[13px] text-[var(--muted-foreground)] mb-4">Almacena planos, fotos y documentos en la nube</div>
                  <button onClick={doMicrosoftLogin} className="px-5 py-2.5 bg-[#0078d4] text-white rounded-lg text-[13px] font-medium hover:bg-[#006cbd] transition-colors cursor-pointer border-none">Conectar con Microsoft</button>
                </div>
              ) : (
                <div className="mb-4">
                  {!showOneDrive ? (
                    <button className="w-full bg-gradient-to-r from-[#00a4ef] to-[#7fba00] text-white border-none rounded-xl py-3 text-sm font-semibold cursor-pointer hover:opacity-90 transition-all flex items-center justify-center gap-2" onClick={() => currentProject && openOneDriveForProject(currentProject.data.name)}>
                      <svg viewBox="0 0 21 21" className="w-4 h-4"><rect x="1" y="1" width="9" height="9" fill="#fff"/><rect x="1" y="11" width="9" height="9" fill="#fff"/><rect x="11" y="1" width="9" height="9" fill="#fff"/><rect x="11" y="11" width="9" height="9" fill="#fff"/></svg>
                      Abrir en OneDrive — {currentProject?.data.name}
                    </button>
                  ) : (
                    <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4">
                      {/* Header with tabs */}
                      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <svg viewBox="0 0 21 21" className="w-4 h-4"><rect x="1" y="1" width="9" height="9" fill="#00a4ef"/><rect x="1" y="11" width="9" height="9" fill="#00a4ef"/><rect x="11" y="1" width="9" height="9" fill="#00a4ef"/><rect x="11" y="11" width="9" height="9" fill="#00a4ef"/></svg>
                          <span className="text-sm font-semibold text-[#00a4ef]">OneDrive — {currentProject?.data.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-0.5 bg-[var(--af-bg3)] rounded-lg p-0.5">
                            <button onClick={() => setOdTab('files')} className={`px-2.5 py-1 rounded-md text-[11px] cursor-pointer transition-all ${odTab === 'files' ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)]'}`}>📋 Archivos</button>
                            <button onClick={() => { setOdTab('gallery'); if (selectedProjectId) loadGalleryPhotos(selectedProjectId); }} className={`px-2.5 py-1 rounded-md text-[11px] cursor-pointer transition-all ${odTab === 'gallery' ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)]'}`}>🖼️ Galería</button>
                          </div>
                          <button className="text-xs px-2 py-1.5 rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] cursor-pointer hover:bg-[var(--af-bg4)] transition-colors" onClick={() => { setShowOneDrive(false); setOneDriveFiles([]); setOdBreadcrumbs([]); setOdSearchQuery(''); setOdSearchResults([]); }}>✕</button>
                        </div>
                      </div>

                      {odTab === 'gallery' ? (
                        /* === Gallery View === */
                        <div>
                          {galleryLoading ? (
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                              {Array.from({length: 8}).map((_, i) => (
                                <div key={i} className="bg-[var(--af-bg3)] rounded-lg animate-pulse aspect-square" />
                              ))}
                            </div>
                          ) : odGalleryPhotos.length === 0 ? (
                            <div className="text-center py-8 text-[var(--af-text3)]">
                              <div className="text-3xl mb-2">🖼️</div>
                              <div className="text-sm">Sin fotos en la galería</div>
                              <div className="text-xs mt-1">Las imágenes de OneDrive aparecerán aquí</div>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                              {odGalleryPhotos.map((photo: any, idx: number) => (
                                <div key={photo.id || idx} className="relative group rounded-lg overflow-hidden cursor-pointer border border-[var(--border)] hover:border-[#00a4ef]/40 transition-all" onClick={() => { setLightboxPhoto(photo); setLightboxIndex(idx); }}>
                                  <img
                                    src={`${photo.thumbnailUrl || photo.thumbnailLarge || photo.webUrl}?access_token=${msAccessToken}`}
                                    alt={photo.name || ''}
                                    className="w-full aspect-square object-cover bg-[var(--af-bg3)]"
                                    loading="lazy"
                                    onError={(e) => { (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/><text x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%23999%22 font-size=%2212%22>🖼️</text></svg>'; }}
                                  />
                                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end">
                                    <div className="w-full px-2 py-1.5 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                                      <div className="text-[10px] text-white truncate">{photo.name || 'Foto'}</div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        /* === Files View === */
                        <div>
                          {/* Toolbar */}
                          <div className="flex items-center gap-2 mb-3 flex-wrap">
                            {/* Breadcrumbs */}
                            <div className="flex items-center gap-1 text-[11px] text-[var(--muted-foreground)] min-w-0 flex-1 overflow-hidden">
                              <button onClick={() => { if (odProjectFolder) { setOdCurrentFolder(odProjectFolder); setOdBreadcrumbs([]); loadOneDriveFiles(odProjectFolder); } }} className="hover:text-[#00a4ef] truncate shrink-0 cursor-pointer bg-transparent border-none text-inherit">OneDrive</button>
                              {odBreadcrumbs.map((crumb, i) => (
                                <React.Fragment key={crumb.id}>
                                  <span className="shrink-0">/</span>
                                  <button onClick={() => navigateToFolder(crumb.id, i)} className="hover:text-[#00a4ef] truncate max-w-[80px] sm:max-w-[120px] cursor-pointer bg-transparent border-none text-inherit">{crumb.name}</button>
                                </React.Fragment>
                              ))}
                            </div>

                            {/* Search */}
                            <div className="relative flex-shrink-0">
                              <input
                                value={odSearchQuery}
                                onChange={(e) => { setOdSearchQuery(e.target.value); if (e.target.value.length > 2) searchOneDriveFiles(e.target.value); else if (!e.target.value) setOdSearchResults([]); }}
                                placeholder="Buscar archivos..."
                                className="w-[150px] sm:w-[180px] pl-7 pr-2.5 py-1.5 text-[11px] rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] outline-none focus:border-[#00a4ef]/40"
                              />
                              <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px]">🔍</span>
                              {odSearching && <div className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 border border-[#00a4ef]/30 border-t-[#00a4ef] rounded-full animate-spin" />}
                            </div>

                            {/* View toggle */}
                            <div className="flex items-center gap-0.5 bg-[var(--af-bg3)] rounded-lg p-0.5">
                              <button onClick={() => setOdViewMode('list')} className={`px-1.5 py-1 rounded-md text-[11px] cursor-pointer transition-all ${odViewMode === 'list' ? 'bg-[var(--card)] text-[var(--foreground)] shadow-sm' : 'text-[var(--muted-foreground)]'}`}>📋</button>
                              <button onClick={() => setOdViewMode('grid')} className={`px-1.5 py-1 rounded-md text-[11px] cursor-pointer transition-all ${odViewMode === 'grid' ? 'bg-[var(--card)] text-[var(--foreground)] shadow-sm' : 'text-[var(--muted-foreground)]'}`}>⊞</button>
                            </div>

                            {/* Upload */}
                            <label className="px-2.5 py-1.5 bg-[#00a4ef] text-white rounded-lg text-[11px] font-medium cursor-pointer hover:bg-[#0091d5] transition-colors flex items-center gap-1">
                              <span>⬆️</span> Subir
                              <input type="file" className="hidden" onChange={handleFileUpload} />
                            </label>
                          </div>

                          {/* Upload progress */}
                          {odUploading && (
                            <div className="mb-3 bg-[var(--af-bg3)] rounded-lg p-3">
                              <div className="flex items-center justify-between mb-1.5">
                                <span className="text-[11px] font-medium truncate max-w-[200px]">{odUploadFile}</span>
                                <span className="text-[10px] text-[var(--muted-foreground)]">{odUploadProgress}%</span>
                              </div>
                              <div className="w-full bg-[var(--border)] rounded-full h-1.5 overflow-hidden">
                                <div className="h-full bg-[#00a4ef] rounded-full transition-all duration-300" style={{ width: `${odUploadProgress}%` }} />
                              </div>
                            </div>
                          )}

                          {/* Drag & drop wrapper */}
                          <div
                            onDragOver={(e) => { e.preventDefault(); setOdDragOver(true); }}
                            onDragLeave={() => setOdDragOver(false)}
                            onDrop={async (e) => { e.preventDefault(); setOdDragOver(false); await handleDroppedFiles(e.dataTransfer.files); }}
                            className={`rounded-lg transition-colors min-h-[120px] ${odDragOver ? 'ring-2 ring-[#00a4ef] bg-[#00a4ef]/5' : ''}`}
                          >
                            {msLoading ? (
                              <div className="flex items-center justify-center py-8">
                                <div className="w-5 h-5 border-2 border-[#00a4ef]/30 border-t-[#00a4ef] rounded-full animate-spin mr-2" />
                                <span className="text-xs text-[var(--muted-foreground)]">Cargando archivos...</span>
                              </div>
                            ) : odSearchQuery && odSearchResults.length > 0 ? (
                              /* Search results */
                              <div className="space-y-1">
                                <div className="text-[10px] text-[var(--muted-foreground)] mb-2">{odSearchResults.length} resultado(s) para &quot;{odSearchQuery}&quot;</div>
                                {odSearchResults.map((f: any) => (
                                  <div key={f.id} className="flex items-center gap-2 py-2 px-2 bg-[var(--af-bg3)] rounded-lg hover:bg-[var(--af-bg4)] transition-colors">
                                    <span className="text-sm">{getFileIcon(f.mimeType || '', f.name)}</span>
                                    <div className="flex-1 min-w-0">
                                      <div className="text-[11px] font-medium truncate">{f.name}</div>
                                      <div className="text-[10px] text-[var(--af-text3)]">{formatFileSize(f.size || 0)}</div>
                                    </div>
                                    <button onClick={() => downloadOneDriveFile(f.id, f.name)} className="text-[10px] text-[#00a4ef] px-1.5 py-0.5 rounded hover:bg-[#00a4ef]/10 cursor-pointer bg-transparent border-none">⬇️</button>
                                  </div>
                                ))}
                              </div>
                            ) : odSearchQuery && !odSearching && odSearchResults.length === 0 ? (
                              <div className="text-center py-8 text-[var(--af-text3)]">
                                <div className="text-sm">Sin resultados para &quot;{odSearchQuery}&quot;</div>
                              </div>
                            ) : oneDriveFiles.length === 0 ? (
                              <div className="text-center py-8 text-[var(--af-text3)]">
                                <div className="text-3xl mb-2">☁️</div>
                                <div className="text-sm">Carpeta vacía</div>
                                <div className="text-xs mt-1">Arrastra archivos aquí o usa el botón &quot;Subir&quot;</div>
                              </div>
                            ) : odViewMode === 'grid' ? (
                              /* Grid view */
                              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                {oneDriveFiles.map((f: any) => (
                                  <div key={f.id} className={`bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg p-2.5 hover:border-[#00a4ef]/30 transition-all group ${f.folder ? 'cursor-pointer' : ''}`} onClick={() => { if (f.folder) { navigateToFolder(f.id); setOdBreadcrumbs(prev => [...prev, { id: f.id, name: f.name }]); } }}>
                                    <div className="w-9 h-9 bg-[var(--af-bg4)] rounded-lg flex items-center justify-center text-base mb-2">{getFileIcon(f.file?.mimeType || f.mimeType || '', f.name)}</div>
                                    <div className="text-[11px] font-medium truncate mb-0.5">
                                      {odRenaming === f.id ? (
                                        <input
                                          autoFocus
                                          value={odRenameName}
                                          onChange={(e) => setOdRenameName(e.target.value)}
                                          onBlur={() => renameOneDriveFile(f.id, odRenameName)}
                                          onKeyDown={(e) => { if (e.key === 'Enter') renameOneDriveFile(f.id, odRenameName); if (e.key === 'Escape') setOdRenaming(null); }}
                                          className="w-full px-1.5 py-0.5 text-[11px] rounded border border-[#00a4ef]/40 bg-[var(--card)] outline-none"
                                          onClick={(e) => e.stopPropagation()}
                                        />
                                      ) : f.name}
                                    </div>
                                    <div className="text-[10px] text-[var(--af-text3)]">{f.folder ? 'Carpeta' : formatFileSize(f.size || 0)}</div>
                                    {f.lastModifiedDateTime && <div className="text-[9px] text-[var(--af-text3)]">{timeAgo(f.lastModifiedDateTime)}</div>}
                                    {!f.folder && (
                                      <div className="flex items-center gap-1 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                                        <button onClick={() => downloadOneDriveFile(f.id, f.name)} className="text-[10px] px-1.5 py-0.5 rounded hover:bg-[var(--card)] cursor-pointer bg-transparent border-none">⬇️</button>
                                        <button onClick={() => { setOdRenaming(f.id); setOdRenameName(f.name); }} className="text-[10px] px-1.5 py-0.5 rounded hover:bg-[var(--card)] cursor-pointer bg-transparent border-none">✏️</button>
                                        <button onClick={() => { if (confirm('¿Eliminar archivo de OneDrive?')) { deleteFromOneDrive(f.id, odCurrentFolder); } }} className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer border-none hover:bg-red-500/20">✕</button>
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              /* List view */
                              <div className="space-y-1">
                                {/* Column headers */}
                                <div className="flex items-center gap-2 px-2 py-1 text-[10px] text-[var(--muted-foreground)] font-medium border-b border-[var(--border)]">
                                  <div className="w-7 shrink-0"></div>
                                  <div className="flex-1 min-w-0">Nombre</div>
                                  <div className="w-[60px] text-right shrink-0 hidden sm:block">Tamaño</div>
                                  <div className="w-[70px] text-right shrink-0 hidden sm:block">Fecha</div>
                                  <div className="w-[60px] shrink-0"></div>
                                </div>
                                {oneDriveFiles.map((f: any) => (
                                  <div key={f.id} className={`flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-[var(--af-bg3)] transition-colors group ${f.folder ? 'cursor-pointer' : ''}`} onClick={() => { if (f.folder) { navigateToFolder(f.id); setOdBreadcrumbs(prev => [...prev, { id: f.id, name: f.name }]); } }}>
                                    <div className="w-7 h-7 bg-[var(--af-bg3)] rounded-md flex items-center justify-center text-sm flex-shrink-0">{getFileIcon(f.file?.mimeType || f.mimeType || '', f.name)}</div>
                                    <div className="flex-1 min-w-0">
                                      {odRenaming === f.id ? (
                                        <input
                                          autoFocus
                                          value={odRenameName}
                                          onChange={(e) => setOdRenameName(e.target.value)}
                                          onBlur={() => renameOneDriveFile(f.id, odRenameName)}
                                          onKeyDown={(e) => { if (e.key === 'Enter') renameOneDriveFile(f.id, odRenameName); if (e.key === 'Escape') setOdRenaming(null); }}
                                          className="w-full px-1.5 py-0.5 text-[11px] rounded border border-[#00a4ef]/40 bg-[var(--card)] outline-none"
                                          onClick={(e) => e.stopPropagation()}
                                        />
                                      ) : (
                                        <div className="text-[11px] font-medium truncate">{f.name}</div>
                                      )}
                                    </div>
                                    <div className="w-[60px] text-right text-[10px] text-[var(--af-text3)] shrink-0 hidden sm:block">{f.folder ? '—' : formatFileSize(f.size || 0)}</div>
                                    <div className="w-[70px] text-right text-[10px] text-[var(--af-text3)] shrink-0 hidden sm:block">{f.lastModifiedDateTime ? timeAgo(f.lastModifiedDateTime) : '—'}</div>
                                    <div className="flex items-center gap-0.5 w-[60px] shrink-0 justify-end opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                                      {!f.folder && (
                                        <>
                                          <button onClick={() => downloadOneDriveFile(f.id, f.name)} className="text-[10px] px-1 py-0.5 rounded hover:bg-[var(--af-bg4)] cursor-pointer bg-transparent border-none" title="Descargar">⬇️</button>
                                          <button onClick={() => { setOdRenaming(f.id); setOdRenameName(f.name); }} className="text-[10px] px-1 py-0.5 rounded hover:bg-[var(--af-bg4)] cursor-pointer bg-transparent border-none" title="Renombrar">✏️</button>
                                        </>
                                      )}
                                      <button onClick={() => { if (confirm('¿Eliminar de OneDrive?')) { deleteFromOneDrive(f.id, odCurrentFolder); } }} className="text-[10px] px-1 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer border-none hover:bg-red-500/20" title="Eliminar">✕</button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-between items-center mb-4">
                <div className="text-sm text-[var(--muted-foreground)]">{projectFiles.length} archivos locales</div>
                <div>
                  <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border-none hover:bg-[var(--af-accent2)] transition-colors" onClick={() => document.getElementById('file-upload-input')?.click()}>
                    + Subir archivo
                  </button>
                  <input id="file-upload-input" type="file" style={{ display: 'none' }} onChange={uploadFile} />
                </div>
              </div>
              {projectFiles.length === 0 ? <div className="text-center py-12 text-[var(--af-text3)]"><div className="text-3xl mb-2">📂</div><div className="text-sm">Sin archivos subidos</div></div> :
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {projectFiles.map(f => (
                  <div key={f.id} className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 hover:border-[var(--input)] transition-all group">
                    <div className="flex items-start justify-between mb-2">
                      <div className="w-10 h-10 bg-[var(--af-bg3)] rounded-lg flex items-center justify-center text-lg">
                        {f.type?.startsWith('image/') ? '🖼️' : f.type === 'application/pdf' ? '📄' : f.type?.includes('video') ? '🎬' : '📎'}
                      </div>
                      <button className="opacity-100 md:opacity-0 md:group-hover:opacity-100 text-xs px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer transition-opacity" onClick={() => deleteFile(f)}>✕</button>
                    </div>
                    <div className="text-sm font-medium truncate mb-0.5">{f.name}</div>
                    <div className="text-[11px] text-[var(--af-text3)]">{fmtSize(f.size)}</div>
                    {f.type?.startsWith('image/') && f.data && <div className="mt-2"><img src={f.data} alt={f.name} className="w-full h-24 object-cover rounded-lg border border-[var(--border)]" loading="lazy" /></div>}
                    {f.data && <a href={f.data} download={f.name} className="text-[11px] text-[var(--af-accent)] mt-2 inline-block hover:underline">Descargar archivo</a>}
                  </div>
                ))}
              </div>}
            </div>)}

            {/* Tab: Obra */}
            {forms.detailTab === 'Obra' && (<div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex gap-1 bg-[var(--af-bg3)] rounded-lg p-1">
                  <button className={`px-3 py-1.5 rounded-md text-[12px] cursor-pointer transition-all ${forms.workView !== 'gantt' ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)] hover:text-[var(--foreground)]'}`} onClick={() => setForms(p => ({ ...p, workView: 'timeline' }))}>Timeline</button>
                  <button className={`px-3 py-1.5 rounded-md text-[12px] cursor-pointer transition-all ${forms.workView === 'gantt' ? 'bg-[var(--card)] text-[var(--foreground)] font-medium shadow-sm' : 'text-[var(--muted-foreground)] hover:text-[var(--foreground)]'}`} onClick={() => setForms(p => ({ ...p, workView: 'gantt' }))}>Gantt</button>
                </div>
                <div className="flex gap-2">
                  {workPhases.length === 0 && <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border-none" onClick={initDefaultPhases}>Inicializar fases</button>}
                </div>
              </div>
              {workPhases.length === 0 ? <div className="text-center py-12 text-[var(--af-text3)]"><div className="text-3xl mb-2">🏗️</div><div className="text-sm">Haz clic en &quot;Inicializar fases&quot; para comenzar el seguimiento</div></div> :
              forms.workView === 'gantt' ? (
                /* Gantt Chart View */
                <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 overflow-x-auto">
                  {(() => {
                    const phasesWithDates = workPhases.filter(ph => ph.data.startDate || ph.data.endDate);
                    const allDates = workPhases.filter(ph => ph.data.startDate).map(ph => new Date(ph.data.startDate).getTime()).concat(workPhases.filter(ph => ph.data.endDate).map(ph => new Date(ph.data.endDate).getTime()));
                    const timelineStart = allDates.length > 0 ? new Date(Math.min(...allDates)) : new Date();
                    const timelineEnd = allDates.length > 0 ? new Date(Math.max(...allDates)) : new Date(timelineStart.getTime() + 30 * 86400000);
                    const totalDays = Math.max(1, Math.ceil((timelineEnd.getTime() - timelineStart.getTime()) / 86400000) + 7);
                    const dayWidth = Math.max(24, Math.min(50, 700 / totalDays));
                    const ganttColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];
                    return phasesWithDates.length === 0 ? (
                      <div className="text-center py-8 text-[var(--muted-foreground)] text-sm">Las fases necesitan fechas de inicio/fin para mostrar el Gantt. Edita las fases para agregar fechas.</div>
                    ) : (
                      <div>
                        <div className="flex text-[10px] text-[var(--muted-foreground)] mb-2 ml-[140px]" style={{ width: totalDays * dayWidth }}>
                          {Array.from({ length: Math.min(totalDays, 30) }, (_, i) => {
                            const d = new Date(timelineStart.getTime() + i * 86400000);
                            return <div key={i} className="flex-shrink-0 text-center" style={{ width: dayWidth }}>{d.getDate()}/{d.getMonth() + 1}</div>;
                          })}
                        </div>
                        {workPhases.map((phase, idx) => {
                          const days = calcGanttDays(phase.data.startDate, phase.data.endDate);
                          const offset = calcGanttOffset(phase.data.startDate, timelineStart.toISOString());
                          const color = ganttColors[idx % ganttColors.length];
                          const isDone = phase.data.status === 'Completado';
                          const isActive = phase.data.status === 'En progreso';
                          return (
                            <div key={phase.id} className="flex items-center mb-1.5">
                              <div className="w-[130px] text-[11px] font-medium truncate pr-2 shrink-0 flex items-center gap-1.5">
                                <div className={`w-2 h-2 rounded-full shrink-0 ${isDone ? 'bg-emerald-500' : isActive ? 'bg-[var(--af-accent)]' : 'bg-[var(--af-bg4)]'}`} />
                                {phase.data.name}
                              </div>
                              <div className="relative h-6" style={{ width: totalDays * dayWidth }}>
                                <div className={`absolute h-6 rounded-md flex items-center px-2 text-[10px] font-medium text-white ${isDone ? 'opacity-70' : ''}`} style={{ left: offset * dayWidth, width: Math.max(days * dayWidth, 20), backgroundColor: color }}>
                                  {days > 2 && phase.data.name.substring(0, 12)}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>
              ) : (
              <div className="relative pl-6">
                <div className="absolute left-[7px] top-2 bottom-2 w-px bg-[var(--input)]" />
                {workPhases.map(phase => {
                  const isActive = phase.data.status === 'En progreso', isDone = phase.data.status === 'Completado';
                  return (<div key={phase.id} className="relative mb-5">
                    <div className={`absolute -left-6 top-1 w-3.5 h-3.5 rounded-full border-2 border-[var(--card)] ${isDone ? 'bg-emerald-500' : isActive ? 'bg-[var(--af-accent)] shadow-[0_0_0_3px_rgba(200,169,110,0.2)]' : 'bg-[var(--af-bg4)] border-[var(--input)]'}`} />
                    <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 hover:border-[var(--input)] transition-all">
                      <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                        <div className="text-sm font-semibold">{phase.data.name}</div>
                        <select className="bg-[var(--af-bg3)] border border-[var(--input)] rounded-md px-2 py-1 text-xs text-[var(--foreground)] outline-none cursor-pointer" value={phase.data.status} onChange={e => updatePhaseStatus(phase.id, e.target.value)}>
                          <option value="Pendiente">Pendiente</option><option value="En progreso">En progreso</option><option value="Completado">Completado</option>
                        </select>
                      </div>
                      {phase.data.description && <div className="text-xs text-[var(--muted-foreground)] mb-2">{phase.data.description}</div>}
                      <div className="flex items-center gap-3 text-[11px] text-[var(--af-text3)]">
                        {phase.data.startDate && <span>Inicio: {phase.data.startDate}</span>}
                        {phase.data.endDate && <span>Fin: {phase.data.endDate}</span>}
                      </div>
                    </div>
                  </div>);
                })}
              </div>
              )}
            </div>)}

            {/* Tab: Portal */}
            {forms.detailTab === 'Portal' && (<div>
              <div className="flex justify-between items-center mb-4">
                <div className="text-sm text-[var(--muted-foreground)]">Vista del cliente</div>
                <button className="flex items-center gap-1.5 bg-[var(--af-accent)] text-background px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border-none" onClick={() => { setForms(p => ({ ...p, appTitle: '', appDesc: '' })); openModal('approval'); }}>+ Nueva aprobación</button>
              </div>
              {/* Client summary */}
              <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5 mb-4">
                <div style={{ fontFamily: "'DM Serif Display', serif" }} className="text-xl mb-2">{currentProject.data.name}</div>
                <div className="text-sm text-[var(--muted-foreground)] mb-3">{currentProject.data.description || 'Sin descripción'}</div>
                <div className="flex items-center gap-3 mb-2"><span className={`text-[11px] px-2 py-0.5 rounded-full ${statusColor(currentProject.data.status)}`}>{currentProject.data.status}</span><span className="text-sm font-medium">{currentProject.data.progress || 0}% completado</span></div>
                <div className="h-1.5 bg-[var(--af-bg4)] rounded-full overflow-hidden"><div className="h-full rounded-full bg-[var(--af-accent)]" style={{ width: (currentProject.data.progress || 0) + '%' }} /></div>
              </div>
              {/* Work phases for client */}
              {workPhases.length > 0 && (<div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5 mb-4">
                <div className="text-[15px] font-semibold mb-3">Fases del proyecto</div>
                <div className="space-y-2">
                  {workPhases.map(ph => (
                    <div key={ph.id} className="flex items-center gap-3 py-1.5">
                      <div className={`w-3 h-3 rounded-full ${ph.data.status === 'Completado' ? 'bg-emerald-500' : ph.data.status === 'En progreso' ? 'bg-[var(--af-accent)]' : 'bg-[var(--af-bg4)]'}`} />
                      <span className="text-sm flex-1">{ph.data.name}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${ph.data.status === 'Completado' ? 'bg-emerald-500/10 text-emerald-400' : ph.data.status === 'En progreso' ? 'bg-[var(--af-accent)]/10 text-[var(--af-accent)]' : 'bg-[var(--af-bg4)] text-[var(--muted-foreground)]'}`}>{ph.data.status}</span>
                    </div>
                  ))}
                </div>
              </div>)}
              {/* Files gallery */}
              {projectFiles.filter(f => f.type?.startsWith('image/')).length > 0 && (<div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5 mb-4">
                <div className="text-[15px] font-semibold mb-3">Galería</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                  {projectFiles.filter(f => f.type?.startsWith('image/')).map(f => (
                    <a key={f.id} href={f.data} download={f.name}><img src={f.data} alt={f.name} className="w-full aspect-square object-cover rounded-lg border border-[var(--border)] hover:border-[var(--af-accent)] transition-all" loading="lazy" /></a>
                  ))}
                </div>
              </div>)}
              {/* Approvals */}
              <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-5">
                <div className="text-[15px] font-semibold mb-3">Aprobaciones</div>
                {approvals.length === 0 ? <div className="text-center py-6 text-[var(--af-text3)] text-sm">Sin solicitudes de aprobación</div> :
                approvals.map(a => (
                  <div key={a.id} className="border border-[var(--border)] rounded-lg p-3 mb-2">
                    <div className="flex items-start justify-between mb-1">
                      <div className="text-sm font-semibold">{a.data.title}</div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${a.data.status === 'Aprobado' ? 'bg-emerald-500/10 text-emerald-400' : a.data.status === 'Rechazado' ? 'bg-red-500/10 text-red-400' : 'bg-amber-500/10 text-amber-400'}`}>{a.data.status}</span>
                    </div>
                    {a.data.description && <div className="text-xs text-[var(--muted-foreground)] mb-2">{a.data.description}</div>}
                    {a.data.status === 'Pendiente' && (
                      <div className="flex gap-2 mt-2">
                        <button className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-md text-xs font-medium cursor-pointer hover:bg-emerald-500 hover:text-white transition-all" onClick={() => updateApproval(a.id, 'Aprobado')}>✓ Aprobar</button>
                        <button className="bg-red-500/10 text-red-400 border border-red-500/30 px-3 py-1 rounded-md text-xs font-medium cursor-pointer hover:bg-red-500 hover:text-white transition-all" onClick={() => updateApproval(a.id, 'Rechazado')}>✕ Rechazar</button>
                        <button className="ml-auto text-xs text-[var(--af-text3)] cursor-pointer hover:text-red-400" onClick={() => deleteApproval(a.id)}>Eliminar</button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>)}
          </div>
  );
}
