'use client';
import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { prioColor, taskStColor } from '@/lib/helpers';
import { MESES, DIAS_SEMANA } from '@/lib/types';

export default function CalendarScreen() {
  const {
    calFilterProject, calMonth, calSelectedDate, calYear, deleteMeeting,
    getUserName, meetings, openEditMeeting, openModal, projects,
    setCalFilterProject, setCalMonth, setCalSelectedDate, setCalYear, setEditingId,
    setForms, tasks,
  } = useApp();

  return (
(() => {
            const today = new Date();
            const todayOnly = new Date(new Date().toDateString()); // midnight today for correct overdue check
            const firstDay = new Date(calYear, calMonth, 1);
            const lastDay = new Date(calYear, calMonth + 1, 0);
            const startDow = (firstDay.getDay() + 6) % 7; // Monday = 0
            const daysInMonth = lastDay.getDate();
            const calTasks = tasks.filter(t => t.data.dueDate && t.data.status !== 'Completado' && (calFilterProject === 'all' || t.data.projectId === calFilterProject));
            const todayStr = today.toISOString().split('T')[0];
            const getTasksForDay = (day: number) => {
              const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              return calTasks.filter(t => t.data.dueDate === dateStr);
            };
            const selectedDayTasks = calSelectedDate ? calTasks.filter(t => t.data.dueDate === calSelectedDate) : [];
            const prevMonth = () => { if (calMonth === 0) { setCalMonth(11); setCalYear(y => y - 1); } else { setCalMonth(m => m - 1); } setCalSelectedDate(null); };
            const nextMonth = () => { if (calMonth === 11) { setCalMonth(0); setCalYear(y => y + 1); } else { setCalMonth(m => m + 1); } setCalSelectedDate(null); };

            // Build calendar grid
            const cells: (number | null)[] = [];
            for (let i = 0; i < startDow; i++) cells.push(null);
            for (let d = 1; d <= daysInMonth; d++) cells.push(d);
            while (cells.length % 7 !== 0) cells.push(null);

            return (<div className="animate-fadeIn">
              {/* Calendar Header */}
              <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
                <div className="flex items-center gap-2">
                  <button className="w-8 h-8 rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] flex items-center justify-center cursor-pointer hover:bg-[var(--af-bg4)] transition-colors" onClick={prevMonth}>
                    <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-[var(--muted-foreground)] fill-none" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
                  </button>
                  <div className="text-[15px] font-semibold min-w-[120px] sm:min-w-[160px] text-center">{MESES[calMonth]} {calYear}</div>
                  <button className="w-8 h-8 rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] flex items-center justify-center cursor-pointer hover:bg-[var(--af-bg4)] transition-colors" onClick={nextMonth}>
                    <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-[var(--muted-foreground)] fill-none" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <select className="bg-[var(--af-bg3)] border border-[var(--border)] rounded-lg px-2.5 py-1.5 text-[11px] text-[var(--foreground)] outline-none cursor-pointer" value={calFilterProject} onChange={e => setCalFilterProject(e.target.value)}>
                    <option value="all">Todos los proyectos</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.data.name}</option>)}
                  </select>
                  <button className="text-[11px] px-2.5 py-1.5 rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] cursor-pointer hover:bg-[var(--af-bg4)] transition-colors" onClick={() => { setCalMonth(today.getMonth()); setCalYear(today.getFullYear()); setCalSelectedDate(today.toISOString().split('T')[0]); }}>Hoy</button>
                </div>
              </div>

              {/* Stats row */}
              <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <div className="flex items-center gap-2"><button className="flex items-center gap-1.5 bg-purple-500/10 text-purple-400 px-3 py-1.5 rounded-lg text-[11px] font-semibold cursor-pointer border border-purple-500/20" onClick={() => { setEditingId(null); setForms(p => ({ ...p, meetTitle: '', meetProject: '', meetDate: calSelectedDate || new Date().toISOString().split('T')[0], meetTime: '09:00', meetDuration: '60', meetDesc: '', meetAttendees: '' })); openModal('meeting'); }}>+ Reunión</button><span className="text-[11px] text-purple-400/70">{meetings.filter(m => m.data.date && m.data.date.startsWith(`${calYear}-${String(calMonth + 1).padStart(2, '0')}`)).length} este mes</span></div>
                <button className="text-[11px] px-2.5 py-1.5 rounded-lg bg-[var(--af-bg3)] border border-[var(--border)] cursor-pointer hover:bg-[var(--af-bg4)] transition-colors" onClick={() => { setCalMonth(today.getMonth()); setCalYear(today.getFullYear()); setCalSelectedDate(today.toISOString().split('T')[0]); }}>Hoy</button>
              </div>
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="bg-red-500/10 rounded-lg p-2.5 text-center">
                  <div className="text-base font-bold text-red-400">{calTasks.filter(t => t.data.priority === 'Alta').length}</div>
                  <div className="text-[9px] text-red-400/70">Urgentes</div>
                </div>
                <div className="bg-amber-500/10 rounded-lg p-2.5 text-center">
                  <div className="text-base font-bold text-amber-400">{calTasks.filter(t => { const d = t.data.dueDate; return d && new Date(d) < todayOnly; }).length}</div>
                  <div className="text-[9px] text-amber-400/70">Vencidas</div>
                </div>
                <div className="bg-blue-500/10 rounded-lg p-2.5 text-center">
                  <div className="text-base font-bold text-blue-400">{calTasks.filter(t => { const d = t.data.dueDate; if (!d) return false; const diff = Math.ceil((new Date(d).getTime() - today.getTime()) / 86400000); return diff >= 0 && diff <= 7; }).length}</div>
                  <div className="text-[9px] text-blue-400/70">Esta semana</div>
                </div>
              </div>

              {/* Calendar Grid */}
              <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl overflow-hidden">
                {/* Day headers */}
                <div className="grid grid-cols-7 border-b border-[var(--border)]">
                  {DIAS_SEMANA.map(d => (
                    <div key={d} className="py-2.5 text-center text-[10px] font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">{d}</div>
                  ))}
                </div>
                {/* Days grid */}
                <div className="grid grid-cols-7">
                  {cells.map((day, idx) => {
                    if (day === null) return <div key={`e-${idx}`} className="min-h-[70px] sm:min-h-[90px] border-b border-r border-[var(--border)] bg-[var(--af-bg3)]/30" />;
                    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                    const isToday = day === today.getDate() && calMonth === today.getMonth() && calYear === today.getFullYear();
                    const isSelected = calSelectedDate === dateStr;
                    const dayTasks = getTasksForDay(day);
                    const isPast = new Date(dateStr) < new Date(today.toISOString().split('T')[0]);
                    return (
                      <div key={day} className={`min-h-[70px] sm:min-h-[90px] border-b border-r border-[var(--border)] p-1 sm:p-1.5 cursor-pointer transition-colors ${isSelected ? 'bg-[var(--af-accent)]/10' : 'hover:bg-[var(--af-bg3)]'} ${isPast && !isToday ? 'opacity-70' : ''}`} onClick={() => setCalSelectedDate(dateStr)}>
                        <div className={`text-[11px] sm:text-[13px] font-medium mb-0.5 ${isToday ? 'w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-[var(--af-accent)] text-background flex items-center justify-center' : 'text-[var(--foreground)]'}`}>
                          {day}
                        </div>
                        <div className="space-y-0.5">
                          {dayTasks.slice(0, 3).map(t => {
                            const proj = projects.find(p => p.id === t.data.projectId);
                            const isOverdue = new Date(t.data.dueDate) < todayOnly;
                            return (
                              <div key={t.id} className={`text-[8px] sm:text-[9px] leading-tight px-1 py-0.5 rounded truncate ${t.data.priority === 'Alta' ? 'bg-red-500/15 text-red-400' : t.data.priority === 'Media' ? 'bg-amber-500/15 text-amber-400' : 'bg-emerald-500/15 text-emerald-400'}`} title={t.data.title}>
                                {isOverdue ? '⚡ ' : ''}{t.data.title}
                              </div>
                            );
                          })}
                          {dayTasks.length > 3 && <div className="text-[8px] text-[var(--muted-foreground)] pl-1">+{dayTasks.length - 3} más</div>}
                          {meetings.filter(m => m.data.date === dateStr).map(m => <div key={m.id} className="text-[8px] sm:text-[9px] leading-tight px-1 py-0.5 rounded truncate bg-purple-500/15 text-purple-400" title={`📅 ${m.data.title} (${m.data.time})`}>📅 {m.data.time}</div>)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Selected day detail */}
              {calSelectedDate && (
                <div className="mt-4 bg-[var(--card)] border border-[var(--border)] rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-[14px] font-semibold">
                      {(() => { const parts = calSelectedDate.split('-'); return `${parseInt(parts[2])} de ${MESES[parseInt(parts[1]) - 1]} ${parts[0]}`; })()}
                    </div>
                    <span className={`text-[11px] px-2 py-0.5 rounded-full ${selectedDayTasks.length === 0 ? 'bg-[var(--af-bg4)] text-[var(--muted-foreground)]' : 'bg-[var(--af-accent)]/10 text-[var(--af-accent)]'}`}>
                      {selectedDayTasks.length} tarea{selectedDayTasks.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  {selectedDayTasks.length === 0 ? (
                    <div className="text-center py-6 text-[var(--af-text3)]"><div className="text-2xl mb-1">📅</div><div className="text-sm">Sin tareas pendientes para este día</div></div>
                  ) : (
                    <div className="space-y-2">
                      {selectedDayTasks.sort((a, b) => {
                        const pOrder = { Alta: 0, Media: 1, Baja: 2 };
                        return (pOrder[a.data.priority as keyof typeof pOrder] || 1) - (pOrder[b.data.priority as keyof typeof pOrder] || 1);
                      }).map(t => {
                        const proj = projects.find(p => p.id === t.data.projectId);
                        const isOverdue = new Date(t.data.dueDate) < todayOnly;
                        return (
                          <div key={t.id} className={`border rounded-lg p-3 ${isOverdue ? 'border-red-500/20 bg-red-500/5' : 'border-[var(--border)] bg-[var(--af-bg3)]'}`}>
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <div className="text-[13px] font-medium">{t.data.title}</div>
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-full flex-shrink-0 ${prioColor(t.data.priority)}`}>{t.data.priority}</span>
                            </div>
                            <div className="flex items-center gap-3 text-[10px] text-[var(--af-text3)]">
                              {proj && <span>📁 {proj.data.name}</span>}
                              <span>👤 {getUserName(t.data.assigneeId)}</span>
                              <span className={`px-1.5 py-0.5 rounded-full ${taskStColor(t.data.status)}`}>{t.data.status}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Reuniones del día seleccionado */}
                  {(() => {
                    const dayMeetings = meetings.filter(m => m.data.date === calSelectedDate);
                    if (dayMeetings.length === 0) return null;
                    return (
                      <div className="mt-3 pt-3 border-t border-[var(--border)]">
                        <div className="flex items-center justify-between mb-2">
                          <div className="text-[12px] font-semibold text-purple-400">📅 Reuniones ({dayMeetings.length})</div>
                          <button className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 cursor-pointer border border-purple-500/20 hover:bg-purple-500/20 transition-colors" onClick={() => { setEditingId(null); setForms(p => ({ ...p, meetTitle: '', meetProject: '', meetDate: calSelectedDate || '', meetTime: '09:00', meetDuration: '60', meetDesc: '', meetAttendees: '' })); openModal('meeting'); }}>+ Nueva</button>
                        </div>
                        <div className="space-y-2">
                          {dayMeetings.sort((a, b) => (a.data.time || '').localeCompare(b.data.time || '')).map(m => {
                            const meetProj = projects.find(p => p.id === m.data.projectId);
                            return (
                              <div key={m.id} className="border border-purple-500/20 rounded-lg p-3 bg-purple-500/5">
                                <div className="flex items-start justify-between gap-2 mb-1">
                                  <div className="text-[13px] font-medium">{m.data.title}</div>
                                  <div className="flex gap-1 flex-shrink-0">
                                    <button className="text-[10px] px-1.5 py-0.5 rounded bg-[var(--af-bg3)] text-[var(--muted-foreground)] cursor-pointer hover:text-[var(--foreground)]" onClick={() => openEditMeeting(m)}>✏️</button>
                                    <button className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 cursor-pointer" onClick={() => deleteMeeting(m.id)}>✕</button>
                                  </div>
                                </div>
                                <div className="flex items-center gap-3 text-[10px] text-[var(--af-text3)]">
                                  <span>🕐 {m.data.time || '09:00'} · {m.data.duration || 60} min</span>
                                  {meetProj && <span>📁 {meetProj.data.name}</span>}
                                </div>
                                {m.data.attendees && m.data.attendees.length > 0 && (
                                  <div className="text-[10px] text-[var(--af-text3)] mt-1">👥 {Array.isArray(m.data.attendees) ? m.data.attendees.join(', ') : m.data.attendees}</div>
                                )}
                                {m.data.description && <div className="text-[11px] text-[var(--muted-foreground)] mt-1.5 leading-relaxed">{m.data.description}</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>);
          })()
  );
}
